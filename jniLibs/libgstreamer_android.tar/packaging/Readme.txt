The instructions for building libgstreamer_android.so on Android.

1. Set up Android-based Gstreamer development environment.
   - Guide Url : https://gstreamer.freedesktop.org/documentation/installing/for-android-development.html
   - GStreamer version : 1.8.4
   
2. create a normal NDK project

3. modify the jni/Android.mk file. it should look like this:
   (reference source : https://gstreamer.freedesktop.org/documentation/tutorials/android/link-against-gstreamer.html)

===
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := tutorial-1
LOCAL_SRC_FILES := tutorial-1.c dummy.cpp
LOCAL_SHARED_LIBRARIES := gstreamer_android
LOCAL_LDLIBS := -llog -landroid
include $(BUILD_SHARED_LIBRARY)

ifndef GSTREAMER_ROOT_ANDROID
$(error GSTREAMER_ROOT_ANDROID is not defined!)
endif

ifeq ($(TARGET_ARCH_ABI),armeabi)
GSTREAMER_ROOT        := $(GSTREAMER_ROOT_ANDROID)/arm
else ifeq ($(TARGET_ARCH_ABI),armeabi-v7a)
GSTREAMER_ROOT        := $(GSTREAMER_ROOT_ANDROID)/armv7
else ifeq ($(TARGET_ARCH_ABI),arm64-v8a)
GSTREAMER_ROOT        := $(GSTREAMER_ROOT_ANDROID)/arm64
else ifeq ($(TARGET_ARCH_ABI),x86)
GSTREAMER_ROOT        := $(GSTREAMER_ROOT_ANDROID)/x86
else ifeq ($(TARGET_ARCH_ABI),x86_64)
GSTREAMER_ROOT        := $(GSTREAMER_ROOT_ANDROID)/x86_64
else
$(error Target arch ABI not supported: $(TARGET_ARCH_ABI))
endif

GSTREAMER_NDK_BUILD_PATH  := $(GSTREAMER_ROOT)/share/gst-android/ndk-build/
GSTREAMER_PLUGINS         := coreelements app udp rtp srtp audioconvert
GSTREAMER_EXTRA_DEPS      := gstreamer-app-1.0
GSTREAMER_EXTRA_LIBS      := -liconv
include $(GSTREAMER_NDK_BUILD_PATH)/gstreamer-1.0.mk
===

4. Build the Project

5. Go to the "build/intermediates/stripped_native_libs" directory.
   Depending on your build variant (debug/release) and ABI options(arm64-v8a, ...), you can find the libgstreamer_android.so file.
   ex> build/intermediates/stripped_native_libs/release/out/lib/arm64-v8a/libgstreamer_android.so